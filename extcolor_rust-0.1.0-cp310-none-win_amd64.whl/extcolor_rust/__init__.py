from .extcolor_rust import *

__doc__ = extcolor_rust.__doc__
if hasattr(extcolor_rust, "__all__"):
    __all__ = extcolor_rust.__all__